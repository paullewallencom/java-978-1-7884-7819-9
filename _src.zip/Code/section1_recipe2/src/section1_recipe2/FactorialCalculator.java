package section1_recipe2;

public class FactorialCalculator {

}
